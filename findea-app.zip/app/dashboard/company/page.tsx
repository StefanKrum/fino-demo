export default function CompanyPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Meine Firma</h1>
      <p className="text-muted-foreground">Unternehmensinformationen und Einstellungen.</p>
    </div>
  )
}
