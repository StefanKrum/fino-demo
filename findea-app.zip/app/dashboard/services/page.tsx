export default function ServicesPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Dienstleistungen</h1>
      <p className="text-muted-foreground">Verfügbare Dienstleistungen für Ihr Unternehmen.</p>
    </div>
  )
}
