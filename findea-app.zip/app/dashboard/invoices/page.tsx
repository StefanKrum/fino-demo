export default function InvoicesPage() {
  return (
    <div className="p-8 bg-gray-100 min-h-full">
      <h1 className="text-2xl font-bold mb-6">Rechnungen</h1>
      <p className="text-muted-foreground">Der Inhalt der Rechnungen wird hier eingefügt.</p>
    </div>
  )
}
