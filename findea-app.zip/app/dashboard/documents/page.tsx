export default function DocumentsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Dokumente</h1>
      <p className="text-muted-foreground">Ihre Dokumente werden hier angezeigt.</p>
    </div>
  )
}
