export default function BalanceSheetPage() {
  return (
    <div className="p-8 bg-gray-100 min-h-full">
      <h1 className="text-2xl font-bold mb-6">Bilanz</h1>
      <p className="text-muted-foreground">Hier kommt der Inhalt der Bilanz hin.</p>
    </div>
  )
}
