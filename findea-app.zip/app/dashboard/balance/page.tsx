export default function BalancePage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Kontoübersicht</h1>
      <p className="text-muted-foreground">Ihr Kontostand und Ihre Transaktionen.</p>
    </div>
  )
}
